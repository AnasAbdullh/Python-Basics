#!/usr/bin/python3

from Math import Calculate

Number1 = int(input("Please Enter Number 1 "))
Number2 = int(input("Please Enter Number 2 "))
OpeartionType = input("Please Enter The Opeartion Type ")



Calculate.ArithmeticOperations(Number1, Number2, OpeartionType)
