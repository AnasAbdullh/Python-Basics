Starts = [  
 'Sol',
 'Alpha Centauri',
 'Barnard',
 'Wolf 359' ,
]


peaks = {
  
  "African" : "Kilimanjaro",
  "Antarctic" : "Vinson",
  "Australian" : "Puncak Jaya",
  "Eurasian" : "Everest",
  "North_American" : "Denali",
  "Pacific" : "Mauna Kea",
  "South_American" : "Aconcagua"
  
}


print(Starts[3])
print(peaks["Pacific"])